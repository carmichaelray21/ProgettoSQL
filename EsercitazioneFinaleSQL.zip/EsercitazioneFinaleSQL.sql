-- Creazione database
CREATE DATABASE ToysGroup;

-- Utilizzo del database creato per effettuare le query successive
USE ToysGroup;

-- Creazione tabella Product
CREATE TABLE Product(
					 ProductKey MEDIUMINT
                     ,ProductName VARCHAR(100)
                     ,ListPrice DECIMAL(10,2)
                     ,CategoryName VARCHAR(50)
                     ,CONSTRAINT PK_Product PRIMARY KEY(ProductKey));

-- Creazione tabella Region
CREATE TABLE Region(
					RegionID SMALLINT
                    ,RegionName VARCHAR(50)
                    ,ContinentName VARCHAR(50)
                    , CONSTRAINT PK_Region PRIMARY KEY(RegionID));
                    
-- Creazione tabella Sales
CREATE TABLE Sales(
					SalesOrderNumber INT
                    ,SalesOrderLineNumber INT
                    ,OrderDate DATE
                    ,RegionID SMALLINT
                    ,ProductKey MEDIUMINT
                    ,UnitPrice DECIMAL(10,2)
                    ,SalesOrderQuantity INT
                    ,SalesAmount DECIMAL(15,2)
                    ,CONSTRAINT PK_Sales PRIMARY KEY(SalesOrderNumber,SalesOrderLineNumber)
                    ,CONSTRAINT FK_Sales_1 FOREIGN KEY(ProductKey) REFERENCES Product(ProductKey)
                    ,CONSTRAINT FK_Sales_2 FOREIGN KEY(RegionID) REFERENCES Region(RegionID)
                    );

                    
-- Popolamento della tabella Product
INSERT INTO Product (ProductKey, ProductName, ListPrice, CategoryName) VALUES
(1, 'Action Figure - Superhero', 19.99, 'Toys'),
(2, 'Dollhouse', 49.99, 'Toys'),
(3, 'Remote Control Car', 29.99, 'Toys'),
(4, 'Board Game - Monopoly', 24.99, 'Games'),
(5, 'LEGO Set - City', 39.99, 'Toys'),
(6, 'Puzzle - Landscape', 14.99, 'Games'),
(7, 'Barbie Doll', 9.99, 'Toys'),
(8, 'Hot Wheels Car Pack', 12.99, 'Toys'),
(9, 'Stuffed Animal - Teddy Bear', 17.99, 'Toys'),
(10, 'Chess Set', 34.99, 'Games'),
(11, 'Science Experiment Kit', 27.99, 'Toys'),
(12, 'Yo-yo', 4.99, 'Toys'),
(13, 'Card Game - Uno', 9.99, 'Games'),
(14, 'Tricycle', 59.99, 'Toys'),
(15, 'Dress-up Costume - Princess', 29.99, 'Toys'),
(16, 'Play-Doh Set', 19.99, 'Toys'),
(17, 'Bicycle', 149.99, 'Toys'),
(18, 'Rubik''s Cube', 7.99, 'Games'),
(19, 'LEGO Set - Star Wars', 59.99, 'Toys'),
(20, 'Basketball', 19.99, 'Sports'),
(21, 'Soccer Ball', 14.99, 'Sports'),
(22, 'Guitar', 79.99, 'Music'),
(23, 'Drum Set', 129.99, 'Music'),
(24, 'Art Supplies Set', 24.99, 'Art'),
(25, 'Science Fiction Book', 12.99, 'Books'),
(26, 'Cooking Playset', 29.99, 'Toys'),
(27, 'Painting Kit', 19.99, 'Art'),
(28, 'Scooter', 39.99, 'Toys'),
(29, 'Remote Control Helicopter', 39.99, 'Toys'),
(30, 'Basketball Hoop', 99.99, 'Sports'),
(31, 'Swing Set', 199.99, 'Toys'),
(32, 'Baseball Bat', 24.99, 'Sports'),
(33, 'Model Airplane Kit', 49.99, 'Toys'),
(34, 'Dinosaur Toy Set', 16.99, 'Toys'),
(35, 'Magic Kit', 29.99, 'Toys'),
(36, 'Fishing Rod', 39.99, 'Sports'),
(37, 'Digital Camera for Kids', 79.99, 'Electronics'),
(38, 'Building Blocks Set', 14.99, 'Toys'),
(39, 'Paint-by-Numbers Kit', 17.99, 'Art'),
(40, 'Video Game - Mario Kart', 49.99, 'Games'),
(41, 'PlayStation Console', 299.99, 'Electronics'),
(42, 'Xbox Console', 349.99, 'Electronics'),
(43, 'Laptop for Kids', 199.99, 'Electronics'),
(44, 'Karaoke Machine', 69.99, 'Music'),
(45, 'Portable DVD Player', 79.99, 'Electronics'),
(46, 'Bluetooth Speaker', 29.99, 'Electronics'),
(47, 'Smartphone for Kids', 149.99, 'Electronics'),
(48, 'Toy Train Set', 24.99, 'Toys'),
(49, 'Water Gun', 9.99, 'Toys'),
(50, 'Swimming Pool', 199.99, 'Outdoor');

-- Popolamento della tabella Region
INSERT INTO Region (RegionID, RegionName, ContinentName) VALUES
(1, 'United States', 'North America'),
(2, 'Canada', 'North America'),
(3, 'Mexico', 'North America'),
(4, 'Brazil', 'South America'),
(5, 'Argentina', 'South America'),
(6, 'Germany', 'Europe'),
(7, 'United Kingdom', 'Europe'),
(8, 'France', 'Europe'),
(9, 'Italy', 'Europe'),
(10, 'Spain', 'Europe'),
(11, 'Russia', 'Europe'),
(12, 'China', 'Asia'),
(13, 'India', 'Asia'),
(14, 'Japan', 'Asia'),
(15, 'South Korea', 'Asia'),
(16, 'Australia', 'Australia'),
(17, 'South Africa', 'Africa'),
(18, 'Egypt', 'Africa'),
(19, 'Nigeria', 'Africa'),
(20, 'Kenya', 'Africa'),
(21, 'Ghana', 'Africa'),
(22, 'Saudi Arabia', 'Asia'),
(23, 'United Arab Emirates', 'Asia'),
(24, 'Turkey', 'Europe'),
(25, 'Greece', 'Europe'),
(26, 'Sweden', 'Europe'),
(27, 'Norway', 'Europe'),
(28, 'Denmark', 'Europe'),
(29, 'Netherlands', 'Europe'),
(30, 'Switzerland', 'Europe'); 

-- Popolamento della tabella Sales
INSERT INTO Sales (SalesOrderNumber, SalesOrderLineNumber, OrderDate, RegionID, ProductKey, UnitPrice, SalesOrderQuantity, SalesAmount)
VALUES
    (1, 1, '2024-04-01', 1, 1, 15.99, 5, 79.95),
    (1, 2, '2024-04-01', 1, 2, 12.49, 3, 37.47),
    (2, 1, '2024-04-02', 2, 3, 9.99, 2, 19.98),
    (2, 2, '2024-04-02', 2, 4, 24.99, 1, 24.99),
    (3, 1, '2024-04-03', 3, 5, 19.99, 4, 79.96),
    (3, 2, '2024-04-03', 3, 6, 7.99, 6, 47.94),
    (4, 1, '2024-04-04', 4, 7, 29.99, 2, 59.98),
    (4, 2, '2024-04-04', 4, 8, 14.99, 3, 44.97),
    (5, 1, '2024-04-05', 5, 9, 39.99, 1, 39.99),
    (5, 2, '2024-04-05', 5, 10, 34.99, 7, 244.93),
    (6, 1, '2024-04-06', 1, 1, 15.99, 5, 79.95),
    (6, 2, '2024-04-06', 1, 2, 12.49, 3, 37.47),
    (7, 1, '2024-04-07', 2, 3, 9.99, 2, 19.98),
    (7, 2, '2024-04-07', 2, 4, 24.99, 1, 24.99),
    (8, 1, '2024-04-08', 3, 5, 19.99, 4, 79.96),
    (8, 2, '2024-04-08', 3, 6, 7.99, 6, 47.94),
    (9, 1, '2024-04-09', 4, 7, 29.99, 2, 59.98),
    (9, 2, '2024-04-09', 4, 8, 14.99, 3, 44.97),
    (10, 1, '2024-04-10', 5, 9, 39.99, 1, 39.99),
    (10, 2, '2024-04-10', 5, 10, 34.99, 7, 244.93),
    (11, 1, '2024-04-11', 1, 1, 15.99, 5, 79.95),
    (11, 2, '2024-04-11', 1, 2, 12.49, 3, 37.47),
    (12, 1, '2024-04-12', 2, 3, 9.99, 2, 19.98),
    (12, 2, '2024-04-12', 2, 4, 24.99, 1, 24.99),
    (13, 1, '2024-04-13', 3, 5, 19.99, 4, 79.96),
    (13, 2, '2024-04-13', 3, 6, 7.99, 6, 47.94),
    (14, 1, '2024-04-14', 4, 7, 29.99, 2, 59.98),
    (14, 2, '2024-04-14', 4, 8, 14.99, 3, 44.97),
    (15, 1, '2024-04-15', 5, 9, 39.99, 1, 39.99),
    (15, 2, '2024-04-15', 5, 10, 34.99, 7, 244.93),
    (16, 1, '2024-04-16', 1, 1, 15.99, 5, 79.95),
    (16, 2, '2024-04-16', 1, 2, 12.49, 3, 37.47),
    (17, 1, '2024-04-17', 2, 3, 9.99, 2, 19.98),
    (17, 2, '2024-04-17', 2, 4, 24.99, 1, 24.99),
    (18, 1, '2024-04-18', 3, 5, 19.99, 4, 79.96),
    (18, 2, '2024-04-18', 3, 6, 7.99, 6, 47.94),
    (19, 1, '2024-04-19', 4, 7, 29.99, 2, 59.98),
    (19, 2, '2024-04-19', 4, 8, 14.99, 3, 44.97),
    (20, 1, '2024-04-20', 5, 9, 39.99, 1, 39.99),
    (20, 2, '2024-04-20', 5, 10, 34.99, 7, 244.93),
    (21, 1, '2024-04-21', 1, 1, 15.99, 5, 79.95),
    (21, 2, '2024-04-21', 1, 2, 12.49, 3, 37.47),
    (22, 1, '2024-04-22', 2, 3, 9.99, 2, 19.98),
    (22, 2, '2024-04-22', 2, 4, 24.99, 1, 24.99),
    (23, 1, '2024-04-23', 3, 5, 19.99, 4, 79.96),
    (23, 2, '2024-04-23', 3, 6, 7.99, 6, 47.94),
    (24, 1, '2024-04-24', 4, 7, 29.99, 2, 59.98),
    (24, 2, '2024-04-24', 4, 8, 14.99, 3, 44.97),
    (25, 1, '2024-04-25', 5, 9, 39.99, 1, 39.99),
    (25, 2, '2024-04-25', 5, 10, 34.99, 7, 244.93),
    (26, 1, '2024-04-26', 1, 1, 15.99, 5, 79.95),
    (26, 2, '2024-04-26', 1, 2, 12.49, 3, 37.47),
    (27, 1, '2024-04-27', 2, 3, 9.99, 2, 19.98),
    (27, 2, '2024-04-27', 2, 4, 24.99, 1, 24.99),
    (28, 1, '2024-04-28', 3, 5, 19.99, 4, 79.96),
    (28, 2, '2024-04-28', 3, 6, 7.99, 6, 47.94),
    (29, 1, '2024-04-29', 4, 7, 29.99, 2, 59.98),
    (29, 2, '2024-04-29', 4, 8, 14.99, 3, 44.97),
    (30, 1, '2024-04-30', 5, 9, 39.99, 1, 39.99);
   



/* Verifica Primary Key tabella Product: verifico che il numero di valori univoci del campo ProductKey 
è equivalente al numero di record della tabella Product */
SELECT count(*) AS NumeroRecord
FROM Product;

SELECT count(DISTINCT ProductKey) AS conteggioProductKey
FROM Product;

/* Verifica Primary Key tabella Region: verifico che il numero di valori univoci del campo RegionID
è equivalente al numero di record della tabella Region */
SELECT count(*) AS NumeroRecord
FROM Region;

SELECT count(DISTINCT RegionID) AS ConteggioRegionID
FROM Region;

/* Verifica Primary Key tabella Sales: verifico che il numero di combinazioni univoche dei valori dei campi SalesOrderNumber e SalesOrderLineNumber
è equivalente al numero di record della tabella Sales */
SELECT count(*) AS NumeroRecord
FROM Sales;

SELECT count( DISTINCT SalesOrderNumber, SalesOrderLineNumber) AS ConteggioChiavePrimariaComposta
FROM Sales;

-- Elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT p.ProductName AS DescrizioneProdotto, YEAR(s.OrderDate) AS Anno, SUM(s.SalesAmount) AS Fatturato
FROM Product AS p INNER JOIN Sales AS s
ON p.ProductKey=s.ProductKey
GROUP BY p.ProductName,YEAR(s.OrderDate)
;

--  Fatturato totale per stato per anno. il risultato è ordinato per data e per fatturato decrescente. 
SELECT RegionName AS Stato ,YEAR(s.OrderDate) AS Anno, SUM(s.salesAmount) AS Fatturato
FROM Sales AS s INNER JOIN Region AS r
ON s.RegionID=r.RegionID
GROUP BY  RegionName,YEAR(s.OrderDate)
ORDER BY YEAR(s.OrderDate) DESC, SUM(s.salesAmount) DESC ;

-- Categoria di articoli maggiormente richiesta dal mercato.
SELECT sub.CategoriaProdotti,sub.QuantitàRichiesta
FROM (SELECT p.CategoryName AS CategoriaProdotti, SUM(s.SalesOrderQuantity) AS QuantitàRichiesta
FROM Sales AS s INNER JOIN Product AS p
ON s.ProductKey=p.ProductKey
GROUP BY p.CategoryName) AS sub
WHERE sub.QuantitàRichiesta= (SELECT MAX(sub1.QuantitàRichiesta) 
							 FROM (SELECT p.CategoryName AS CategoriaProdotti, SUM(s.SalesOrderQuantity) AS QuantitàRichiesta
								   FROM Sales AS s INNER JOIN Product AS p
								   ON s.ProductKey=p.ProductKey
								   GROUP BY p.CategoryName) AS sub1);


-- Quali sono, se ci sono, i prodotti invenduti.

-- Approccio1
SELECT DISTINCT p.ProductName
FROM Product AS p LEFT JOIN Sales AS s
ON p.ProductKey=s.ProductKey
WHERE s.SalesOrderNumber IS NULL
ORDER BY P.ProductName;

-- Approccio2
SELECT ProductName
FROM Product
WHERE ProductKey NOT IN (SELECT DISTINCT ProductKey FROM Sales)
ORDER BY ProductName;

-- Elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT p.ProductName AS Prodotto, MAX(s.OrderDate) AS DataVenditaPiùRecente
FROM Sales AS s INNER JOIN Product AS p
ON s.ProductKey=p.ProductKey
GROUP BY p.ProductName;